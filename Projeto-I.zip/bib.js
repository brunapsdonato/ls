const listaCategorias = [
  {name: 'Início',
   link: '#',
  },
  {
    name: 'Bases',
    image: '../images/base liquida.jpg',
    link: 'base/base.html',
    descricao:'Nada melhor que uma base boa para tratar sua pele e cobrir aquelas marquinhas que incomodam.'
  },
  {
    name: 'Blushes',
    image: '../images/blushcreme.jpg',
    link: './blush/resenhablush.html',
    descricao:'Um blush poderoso para dar aquele ar saudável.'
  },
  {
    name: 'Pincéis',
    image: '../images/pinceis vermelhos.jpg',
    link: 'pincel/pincel.html',
    descricao:'Vários pincéis para ajudar a fazer aquela maquiagem incrível'
  },
  {
    name: 'Lábios',
    image: '../images/batom.jpg',
    link: 'labios/labios.html',
    descricao:'Batons e liptint para deixar sua boca um arraso!'
  },
  {name: 'Loja Física',
   link: 'loja/loja.html',
  },
];

export default listaCategorias;